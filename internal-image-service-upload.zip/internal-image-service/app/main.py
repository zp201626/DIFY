from __future__ import annotations

import hashlib
import ipaddress
import os
import secrets
from pathlib import Path
from typing import Iterable

from fastapi import FastAPI, File, HTTPException, Request, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, JSONResponse, RedirectResponse
from PIL import Image, UnidentifiedImageError

DATA_DIR = Path(os.getenv("IMAGE_DATA_DIR", "/data/images"))
MAX_BYTES = int(os.getenv("MAX_UPLOAD_BYTES", str(20 * 1024 * 1024)))
MAX_PIXELS = int(os.getenv("MAX_IMAGE_PIXELS", "50000000"))
PUBLIC_BASE_URL = os.getenv("PUBLIC_BASE_URL", "").rstrip("/")
ALLOWED_ORIGINS = [x.strip() for x in os.getenv("CORS_ALLOW_ORIGINS", "*").split(",") if x.strip()]
TRUSTED_NETWORKS = tuple(
    ipaddress.ip_network(x.strip())
    for x in os.getenv(
        "TRUSTED_NETWORKS", "10.0.0.0/8,172.16.0.0/12,192.168.0.0/16,127.0.0.0/8"
    ).split(",")
    if x.strip()
)
ALLOWED_EXTENSIONS = {".jpg", ".jpeg", ".png", ".gif", ".webp", ".bmp", ".svg"}
CONTENT_TYPES = {
    ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png",
    ".gif": "image/gif", ".webp": "image/webp", ".bmp": "image/bmp", ".svg": "image/svg+xml",
}

app = FastAPI(title="Internal Image Service", docs_url=None, redoc_url=None)
app.add_middleware(
    CORSMiddleware,
    allow_origins=ALLOWED_ORIGINS,
    allow_credentials=False,
    allow_methods=["GET", "POST", "OPTIONS"],
    allow_headers=["*"],
)


def client_allowed(request: Request) -> bool:
    host = request.client.host if request.client else ""
    try:
        address = ipaddress.ip_address(host)
        return any(address in network for network in TRUSTED_NETWORKS)
    except ValueError:
        return False


@app.middleware("http")
async def internal_only(request: Request, call_next):
    if not client_allowed(request):
        return JSONResponse({"detail": "internal network access required"}, status_code=403)
    return await call_next(request)


def safe_name(digest: str, suffix: str) -> Path:
    return DATA_DIR / f"{digest}{suffix}"


def public_url(request: Request, filename: str) -> str:
    base = PUBLIC_BASE_URL or str(request.base_url).rstrip("/")
    return f"{base}/images/{filename}"


def validate_image(data: bytes, suffix: str) -> None:
    if len(data) > MAX_BYTES:
        raise HTTPException(413, f"file exceeds {MAX_BYTES} bytes")
    if suffix == ".svg":
        if b"<svg" not in data[:4096].lower():
            raise HTTPException(415, "invalid SVG image")
        return
    try:
        with Image.open(__import__("io").BytesIO(data)) as image:
            if image.width * image.height > MAX_PIXELS:
                raise HTTPException(413, "image dimensions are too large")
            image.verify()
    except (UnidentifiedImageError, OSError):
        raise HTTPException(415, "unsupported or invalid image")


@app.get("/", response_class=HTMLResponse)
async def upload_page(request: Request):
    if not client_allowed(request):
        raise HTTPException(403, "internal network access required")
    return HTMLResponse("""<!doctype html><html lang='zh-CN'><meta charset='utf-8'><meta name='viewport' content='width=device-width,initial-scale=1'><title>内网图片上传</title><style>body{font-family:system-ui;max-width:680px;margin:48px auto;padding:0 20px}form{border:1px solid #ddd;border-radius:12px;padding:24px}button{margin-top:16px;padding:9px 18px}#result{margin-top:20px;word-break:break-all}small{color:#666}</style><h1>内网图片上传</h1><p><small>图片按内容寻址保存，已存在的图片不会被覆盖、修改或删除。</small></p><form id='f'><input id='file' name='file' type='file' accept='image/*' required><br><button>上传</button></form><div id='result'></div><script>f.onsubmit=async e=>{e.preventDefault();result.textContent='上传中…';try{let r=await fetch('/api/upload',{method:'POST',body:new FormData(f)}),j=await r.json();if(!r.ok)throw Error(j.detail||r.status);result.innerHTML=`<p>上传成功：</p><input style="width:100%" value="${j.url}" readonly onclick="this.select()"><p><img src="${j.url}" style="max-width:100%"></p>`}catch(x){result.textContent='上传失败：'+x.message}}</script>""")


@app.get("/healthz")
async def healthz():
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    return {"status": "ok"}


@app.post("/api/upload")
async def upload(request: Request, file: UploadFile = File(...)):
    if not client_allowed(request):
        raise HTTPException(403, "internal network access required")
    original = Path(file.filename or "").name
    suffix = Path(original).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS:
        raise HTTPException(415, "only jpg/jpeg/png/gif/webp/bmp/svg files are supported")
    data = await file.read(MAX_BYTES + 1)
    validate_image(data, suffix)
    digest = hashlib.sha256(data).hexdigest()
    target = safe_name(digest, suffix)
    DATA_DIR.mkdir(parents=True, exist_ok=True)
    if not target.exists():
        temp = DATA_DIR / f".{digest}.{secrets.token_hex(8)}.tmp"
        temp.write_bytes(data)
        os.chmod(temp, 0o444)
        os.replace(temp, target)
        os.chmod(target, 0o444)
    return {"url": public_url(request, target.name), "filename": target.name, "sha256": digest}


@app.get("/images/{filename}")
async def image(filename: str):
    # Static serving is implemented with a controlled file response in main.py below.
    suffix = Path(filename).suffix.lower()
    if suffix not in ALLOWED_EXTENSIONS or Path(filename).name != filename:
        raise HTTPException(404, "image not found")
    target = DATA_DIR / filename
    if not target.is_file():
        raise HTTPException(404, "image not found")
    from fastapi.responses import FileResponse
    return FileResponse(target, media_type=CONTENT_TYPES[suffix], headers={"Cache-Control": "public, max-age=31536000, immutable", "X-Content-Type-Options": "nosniff"})


@app.api_route("/images/{filename}", methods=["PUT", "PATCH", "DELETE"])
async def immutable(filename: str):
    raise HTTPException(405, "images are read-only")
