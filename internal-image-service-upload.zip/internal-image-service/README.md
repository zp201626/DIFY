# 内网静态图片服务

## 启动

1. 修改 `docker-compose.yml` 中的内网绑定地址、`PUBLIC_BASE_URL` 和 Dify 实际来源；不要使用公网地址，也不要把端口映射为 `0.0.0.0:8080`。
2. Linux 部署机首次启动前执行 `sudo chown -R 10001:10001 data`，保证容器非 root 用户可以写入图片目录（Docker Desktop 通常会自动处理共享目录权限）。
3. 在部署机执行：

```bash
docker compose up -d --build
```

上传页面：`http://<内网地址>:8080/`，健康检查：`/healthz`。

## 设计约束

- 上传后使用文件内容的 SHA-256 作为文件名，同一内容幂等；已有文件不会覆盖。
- `/images/*` 只允许 GET/HEAD，PUT/PATCH/DELETE 返回 405；文件以 0444 保存。
- 只接受常见图片格式，默认单文件 20 MiB，并校验图片内容及像素上限。
- CORS 通过 `CORS_ALLOW_ORIGINS` 配置。若 Dify 与图片服务同源，可填具体来源；调试时才使用 `*`。
- 应用只允许 `TRUSTED_NETWORKS` 中的客户端地址。生产环境仍须在防火墙/安全组/内网网关阻断公网入站，Docker 端口绑定到内网网卡。
- 仅将非涉密图片放入 `data/`；请对该目录做备份和磁盘配额管理。

## Dify 使用

把上传接口返回的 `url` 写入知识库，例如：

```markdown
![产品图片](http://192.168.1.20:8080/images/<sha256>.png)
```

该 URL 不含临时会话 token，Dify 的 `<img>` 和飞书内置浏览器只要能访问同一内网地址即可读取。
